#include <iostream>

using namespace std;

class node
{
public:
      // Data
      int value;
      node *next;

      // Method Function()
      node();
};

node::node(){
      int v;
      value = v;
      next = NULL;
}

class linkedlist
{
node *head;
public:
      /* Method Functions */

      //Construtor Inicial
      linkedlist();

      //Inserção de um valor (nó) no começo da lista 
      void insert_beggining(int v);

      //Print da lista
      void print();

      //Deleta um valor específico da lista
      void del(int v);

      //Procura por um valor na lista
      void search(int v);

      // Print da lista na forma reversa
      void print_reverse();
};

linkedlist::linkedlist()
{
      head = NULL;
}

void linkedlist::insert_beggining(int v)
{
      node *temp = new node();
      temp->value = v;
      temp->next = head;
      head = temp;
}

void linkedlist::print(){
      if (head == NULL)
      {
            cout << "List is empty" << endl;
      }
      else
      {
            node *ptr = new node();
            ptr = head;
            while (ptr != NULL)
            {
                  cout << ptr->value << "->";
                  ptr = ptr->next;
            }
            cout << "NULL" << endl;
            
      }   
}

void linkedlist::print_reverse(){
      if (head == NULL)
      {
            cout << "List is empty" << endl;
      }
      
      else
      {
            node *temp = new node();
            node *ptr = new node();

            temp = head;
            ptr = head->next;

            // brb
      }
      
}

void linkedlist::del(int v){
      //caso em que a lista está vazia
      if (head == NULL)
      {
            cout << "Lista vazia, não se pode remover nada" << endl;
      }

      // caso em que o valor já está no head da lista.
      else if (head->value == v)
      {
            node *curr = new node();
            curr = head;
            head = head->next;
            delete curr;
      }

      // caso em que o valor não está no head e a lista não está vazia.
      else
      {
            // o node prev serve para armazenar o nó anterior ao que será removido, caso o valor exista na lista
            node *prev = new node();
            prev = head;

            // o curr vai estar uma posição a frente do head, pois já sabemos que o valor não está no head.
            node *curr = new node();
            curr = head->next;
            while (curr != NULL)
            {
                  //se o valor que o curr assumir for igual ao valor removido, o loop é quebrado.
                  if (curr->value == v)
                  {
                        break;
                  }

                  // caso o valor não seja igual, o prev vai avançar para o curr e o curr vai avançar para uma posição anterior + 1
                  else
                  {
                        prev = curr;
                        curr = curr->next;
                  }
                  
            }

            // se o curr terminar nulo, isso indica que o valor não está presente na lista.
            if (curr == NULL)
            {
                  printf("O valor %d não está na lista e portanto não pode ser removido\n", v);
            }

            // caso o curr não seja nulo, isso significa que o valor existe na lista. então, o next do prev vai apontar agora para o next do curr.
            // o curr é removido, já que a função é pra deletar.
            else
            {
                  prev->next = curr->next;
                  delete curr;
            }
            
      } 
}

void linkedlist::search(int v){
      node *temp = new node();
      temp = head;
      int i = 0;
      while (temp != NULL)
      {
            if (temp->value == v)
            {

                  break;
            }
            else
            {
                  temp = temp->next;
                  i++;
            }
            
      }
      if (temp == NULL)
      {
            printf("O valor %d não está na lista\n", v);
      }
      else
      {
            printf("O valor %d está na lista na posição %d\n", v, i);
      }
}

int main(){
      int number;
      scanf("Input the number of nodes: %d", &number);

      linkedlist tiny;
      int valor = 0;
      for (int i = 1; i <= number; i++)
      {
            printf("Input data for node %d", &i);
            scanf("%d", &valor);
            tiny.insert_beggining(valor);
      }
}