#include <iostream>

using namespace std;

class node
{
public:
      // Data
      int value;
      node *next;

      // Method Function()
      node();
};

node::node(){
      int v;
      value = v;
      next = NULL;
}

