#include <iostream>
#include "node.h";

using namespace std;

class stack
{
node *top;
public:
      /* Method Functions */

      // Construtor inicial
      stack();

      //Inserir (pilha só pode inserir no começo)
      void insert(int v);

      //Deletar (pilha só deleta do começo)
      void del();

      //Printar pilha;
      void print();
};

stack::stack()
{
      top = NULL;
}

void stack::insert(int v)
{
      node *temp = new node();
      temp->value = v;
      temp->next = top;
      top = temp;
}

void stack::del(){
      node *ptr = new node();
      ptr = top;
      ptr = top->next;
      delete(top);
      top = ptr;
}

void stack::print(){
      node *temp = new node();
      temp = top;
      while (temp != NULL)
      {
            cout << temp->value << endl;
            cout << "|" << endl;
            temp = temp->next;
      }
      cout << "NULL" << endl;
}

